import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JMenu;
import javax.swing.JMenuBar;

public class pController {

	MyMainFrame mainframe = null; // Main Frame
	LayerFrame layer = null; // Layer Frame
	myViewPanel myPanel = null;
	myMenuPanel myMenu = null;
	myColorTable myColor = new myColorTable();

	
	ArrayList<Shape> mylist = new ArrayList<Shape>(); // My List!
	
	pController()
	{
		// Initialize
		this.Initial();
		
		for(int i=0;i<21;i++)
		{
			myColor.colors[i].addActionListener(new SelectColor(i));
		}		
	}
	
	public void Initial()
	{
		
		mainframe = new MyMainFrame();
		myPanel = new myViewPanel();
		myMenu = new myMenuPanel();
		
		mainframe.setLayout(new BorderLayout());
		mainframe.add(myMenu,BorderLayout.NORTH);
		mainframe.add(myPanel,BorderLayout.CENTER);
		myMenu.add(myColor);
		
		
		layer = new LayerFrame();
		
		
		for(int i=0;i<20;i++)
		{
			myColor.colors[i].addActionListener(new SelectColor(i));
		}
		myColor.myBox.confirm.addActionListener(new ConfirmColor());
	}
	
	class SelectColor implements ActionListener
	{

		int i;
		
		SelectColor(int input)
		{
			i=input;
		}
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			Color tmp = myColor.mycolors[i];
			
			myColor.selected = tmp;
			
			if(i==20) // if i == 20, it's no color! so we need to setOpaque false!
				myColor.now2.setOpaque(false);
			else
				myColor.now2.setOpaque(true);

			myColor.now2.setBackground(tmp);
		}	
	}
	
	class ConfirmColor implements ActionListener
	{

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			Color tmp = myColor.myBox.getColor();
			
			myColor.now2.setOpaque(true);
			
			myColor.selected = tmp;
			myColor.now2.setBackground(tmp);
		}
		
	}
}
