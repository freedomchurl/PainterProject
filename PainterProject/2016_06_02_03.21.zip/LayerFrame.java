import java.awt.Color;

import javax.swing.JColorChooser;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class LayerFrame extends JFrame{
	
	JPanel main = new JPanel();
	
	LayerFrame()
	{
		super("Layer");
	
		main.setBackground(Color.WHITE);
		this.add(main);
		
		//JColorChooser a = new JColorChooser();
		//main.add(a);
		
		this.setVisible(true);
		this.setLocation(1540,8);
		this.setDefaultCloseOperation(this.DISPOSE_ON_CLOSE);
		this.setSize(350, 600);
	}
}
