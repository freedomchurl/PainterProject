
public class Diamond {

}
