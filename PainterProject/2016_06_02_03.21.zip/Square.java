
public class Square {

}
