
public class Triangle {

}
