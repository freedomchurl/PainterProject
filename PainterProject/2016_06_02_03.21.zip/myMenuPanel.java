import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class myMenuPanel extends JPanel{

	//myColorTable myColor = new myColorTable();
	
	JPanel left = new JPanel();
	JPanel right = new JPanel();
	JPanel right_left = new JPanel();
	
	JPanel left_left = new JPanel();
	JPanel left_center = new JPanel();
	JPanel left_right = new JPanel();
	
	JPanel right_left_right = new JPanel();
	JPanel right_left_left = new JPanel();
	
	JButton [] myButtons = new JButton[8];
	Font myFont = new Font("��������",Font.PLAIN,20);
	
	String [] ButtonsName = {"��","�簢��","�ﰢ��","����","�ٰ���","������","�̵�","��ĥ�ϱ�"};
	
	myMenuPanel()
	{
		this.setLayout(new GridLayout(1,2));
		
		left.setBackground(new Color(136,173,236));
		this.add(left);
		this.add(right);
		
		right.setLayout(new GridLayout(1,2));
		right.add(right_left);
		right_left.setBackground(new Color(136,173,236));
		//right.add(myColor);
		
		right_left.setLayout(new GridLayout(1,2));
		right_left.add(right_left_left);
		right_left.add(right_left_right);
		
		right_left_right.setBackground(new Color(136,173,236));
		right_left_left.setLayout(new GridLayout(2,4));
		
		Initial();
		
		this.setBackground(new Color(136,173,236));
		this.setPreferredSize(new Dimension(1500,120));
	}
	
	public void Initial()
	{
		for(int i=0;i<8;i++)
		{
			myButtons[i] = new JButton(new ImageIcon("Resource/" + Integer.toString(i) +".png"));
			myButtons[i].setFont(myFont);
			//myButtons[i].setForeground(Color.WHITE);
			// Bonus Action! Add!
			
			//myButtons[i].setText(ButtonsName[i]);
			myButtons[i].setToolTipText(ButtonsName[i]);;
			myButtons[i].setBackground(new Color(255,255,255));
			//myButtons[i].setBorderPainted(false);
			myButtons[i].setFocusPainted(false);
			right_left_left.add(myButtons[i]);
		}
		
	
		
	}
	
	
	
	}
